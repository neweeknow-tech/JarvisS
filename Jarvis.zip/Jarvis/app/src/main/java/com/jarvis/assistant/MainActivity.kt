package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var sr: SpeechRecognizer? = null
    private var wake = false
    private var torch = false
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView

    private val aliases = mapOf(
        "ютуб" to "youtube", "ютьюб" to "youtube", "телеграм" to "telegram", "телеграмм" to "telegram",
        "ватсап" to "whatsapp", "вотсап" to "whatsapp", "инстаграм" to "instagram", "тикток" to "tiktok",
        "хром" to "chrome", "почту" to "gmail", "почта" to "gmail", "гмейл" to "gmail",
        "камеру" to "камера", "галерею" to "галерея", "спотифай" to "spotify",
        "вк" to "vk", "вконтакте" to "vk", "карты" to "maps", "настройки" to "настройки"
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0a0614"))
            setPadding(32, 80, 32, 32); gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply { text = "J.A.R.V.I.S"; textSize = 22f; setTextColor(Color.parseColor("#b45cff")); gravity = Gravity.CENTER })
        status = TextView(this).apply { text = "Нажмите на кнопку и говорите"; setTextColor(Color.parseColor("#00e1ff")); gravity = Gravity.CENTER; setPadding(0, 24, 0, 24) }
        root.addView(status)
        val mic = Button(this).apply { text = "🎤"; textSize = 40f; setOnClickListener { wake = false; startListening() } }
        root.addView(mic, LinearLayout.LayoutParams(300, 300))
        val sw = Switch(this).apply { text = "Слушать постоянно («Джарвис, …»)"; setTextColor(Color.WHITE); setPadding(0, 24, 0, 24)
            setOnCheckedChangeListener { _, on -> wake = on; if (on) startListening() else sr?.cancel() } }
        root.addView(sw)
        val et = EditText(this).apply { hint = "Или напишите команду"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); imeOptions = EditorInfo.IME_ACTION_SEND; setSingleLine()
            setOnEditorActionListener { v, _, _ -> val t = v.text.toString(); v.text = ""; if (t.isNotBlank()) handle(t); true } }
        root.addView(et, LinearLayout.LayoutParams(-1, -2))
        logView = TextView(this).apply { setTextColor(Color.parseColor("#d8ccff")); textSize = 15f }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        log("Готов к работе, сэр. Скажите: «открой календарь», «включи ютуб», «будильник на 7:30», «таймер на 5 минут», «позвони 112», «маршрут до вокзала», «фонарик», «найди …».")
    }

    override fun onInit(s: Int) {
        ttsReady = s == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts.language = Locale("ru", "RU")
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onError(id: String?) { after() }
                override fun onDone(id: String?) { after() }
                private fun after() = ui.post { if (wake) startListening() }
            })
        }
    }

    private fun log(t: String) { logView.append(t + "\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }
    private fun setStatus(t: String) = ui.post { status.text = t }

    private fun say(t: String) {
        log("Джарвис: $t")
        if (ttsReady) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j") else if (wake) startListening()
    }

    // ---------- Речь -> текст ----------
    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { setStatus("Нет сервиса распознавания речи. Установите/обновите приложение Google."); return }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { setStatus(if (wake) "Жду «Джарвис»…" else "Слушаю…") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { setStatus("Думаю…") }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(e: Int) {
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { setStatus("Нет доступа к микрофону"); wake = false; return }
                    if (wake) ui.postDelayed({ if (wake) startListening() }, 600)
                    else setStatus(if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) "Не расслышал, нажмите ещё раз" else "Ошибка распознавания ($e)")
                }
                override fun onResults(res: Bundle?) {
                    val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    if (wake) {
                        val m = Regex("(?i)(джарвис|джарвиз|jarvis)[,\\s]*(.*)").find(t)
                        if (m != null) handle(m.groupValues[2].ifBlank { "привет" }) else ui.post { startListening() }
                    } else if (t.isNotBlank()) handle(t) else setStatus("Не расслышал")
                }
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU"))
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) {
        if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) startListening() else setStatus("Разрешите микрофон в настройках приложения")
    }

    // ---------- Команды ----------
    private fun go(i: Intent): Boolean = try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e: Exception) { false }

    private fun handle(raw: String) {
        log("Вы: $raw")
        val s = raw.lowercase(Locale("ru")).replace(Regex("^(джарвис|джарвиз)[,\\s]*"), "").trim()
        setStatus("")
        say(run(s))
    }

    private fun run(s: String): String {
        if (Regex("который час|сколько времени").containsMatchIn(s)) return "Сейчас " + SimpleDateFormat("HH:mm", Locale("ru")).format(Date())
        if (Regex("какое число|какая дата|какой сегодня день").containsMatchIn(s)) return "Сегодня " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale("ru")).format(Date())

        Regex("будильник на (\\d{1,2})(?:[:.\\s]+(\\d{1,2}))?").find(s)?.let {
            val h = it.groupValues[1].toInt(); val m = it.groupValues[2].ifBlank { "0" }.toInt()
            val ok = go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return if (ok) "Будильник на %d:%02d установлен.".format(h, m) else "Не удалось открыть будильник."
        }
        Regex("таймер на (\\d+)\\s*(секунд|сек|минут|мин|час)").find(s)?.let {
            val n = it.groupValues[1].toInt(); val u = it.groupValues[2]
            val sec = n * if (u.startsWith("сек")) 1 else if (u.startsWith("час")) 3600 else 60
            go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Таймер на $n ${u} запущен."
        }
        if (s.contains("календар")) {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR)
            return if (go(i)) "Открываю календарь." else openApp("календарь")
        }
        Regex("(?:включи|поставь|найди на ютубе|ютуб)\\s+(.+)").find(s)?.let {
            val q = it.groupValues[1].removePrefix("в ютубе ").removePrefix("на ютубе ")
            val yt = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
            if (!go(yt)) go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
            return "Ищу $q на ютубе."
        }
        if (Regex("^(?:открой|запусти|включи)\\s+ютуб").containsMatchIn(s)) return openApp("youtube")
        Regex("(?:открой|запусти|открыть)\\s+(.+)").find(s)?.let { return openApp(it.groupValues[1]) }
        Regex("(?:позвони|набери)\\s+([+\\d][\\d\\s\\-]{2,})").find(s)?.let {
            go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + it.groupValues[1].replace(Regex("[\\s\\-]"), "")))); return "Набираю номер."
        }
        Regex("(?:маршрут до|как доехать до|навигация до|поехали на)\\s+(.+)").find(s)?.let {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(it.groupValues[1])))); return "Строю маршрут до ${it.groupValues[1]}."
        }
        Regex("(?:найди|загугли|поищи)\\s+(.+)").find(s)?.let {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(it.groupValues[1])))); return "Ищу ${it.groupValues[1]}."
        }
        if (s.contains("фонарик") || s.contains("фонарь")) {
            val on = !s.contains("выключ")
            return try {
                val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], on); torch = on
                if (on) "Фонарик включён." else "Фонарик выключен."
            } catch (e: Exception) { "Не удалось управлять фонариком." }
        }
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (Regex("громче|прибавь").containsMatchIn(s)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); return "Громкость увеличена." }
        if (Regex("тише|убавь").containsMatchIn(s)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return "Громкость уменьшена." }
        if (Regex("пауза|стоп музык|останови музык|продолжи").containsMatchIn(s)) { media(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return "Готово." }
        if (Regex("следующ").containsMatchIn(s)) { media(KeyEvent.KEYCODE_MEDIA_NEXT); return "Следующий трек." }
        if (Regex("предыдущ").containsMatchIn(s)) { media(KeyEvent.KEYCODE_MEDIA_PREVIOUS); return "Предыдущий трек." }
        if (s.contains("вай") && s.contains("фай")) { go(Intent(Settings.ACTION_WIFI_SETTINGS)); return "Открываю настройки Wi‑Fi." }
        if (s.contains("блютуз") || s.contains("bluetooth")) { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Открываю настройки Bluetooth." }
        if (Regex("привет|здравствуй").containsMatchIn(s)) return "Здравствуйте, сэр. Чем могу помочь?"
        return "Простите, сэр, такой команды я пока не знаю."
    }

    private fun media(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun openApp(nameRaw: String): String {
        val name = nameRaw.trim().removeSuffix(".")
        val t = (aliases[name] ?: name).lowercase()
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == t }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(t) }
            ?: apps.firstOrNull { it.activityInfo.packageName.lowercase().contains(t) }
        val i = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        return if (i != null && go(i)) "Открываю ${hit.loadLabel(pm)}." else "Не нашёл приложение «$name»."
    }

    override fun onDestroy() { sr?.destroy(); tts.shutdown(); super.onDestroy() }
}
